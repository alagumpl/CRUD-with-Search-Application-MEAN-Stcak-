  /**
     * Main Module
     */
(function () {
    'use strict';
    angular.module('app.data',['angularUtils.directives.dirPagination']);
            /**
         * @memberof module:app.data
         *
         * @requires ui.bootstrap
         * @requires angularUtils.directives.dirPagination
         * @ngInject
         */

}());