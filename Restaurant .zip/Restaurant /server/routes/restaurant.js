var Restaurant = require('../models/restaurants'),
    express = require('express'),
    router = express.Router();

//configure routes
router.route('/restaurant')
    .get(getRestaurant)
    .post(addRestaurant);

router.route('/restaurant/:id')
    .put(updateRestaurant)
    .get(getRestaurantById)
    .delete(deleteRestaurant);

//Get the All the Restaurant Details  
function getRestaurant(req, res) {
    Restaurant.find({}, function(err, restaurants) {
        if (err)
            res.send(err);

        res.json(restaurants);
    });
}
//Create the New Restaurant
function addRestaurant(req, res) {
    var restaurant = new Restaurant(req.body);
    Restaurant.count({}, function(err, count) {
        restaurant.restaurantId = setRestaurantId("TN_R", count);
        restaurant.save(function(err) {
            if (err)
                res.send(err);
            res.send({
                message: 'Successfully Added'
            });
        });
    })
}
//Update the Restaurant Details for Particular Id
function updateRestaurant(req, res) {
    Restaurant.findOne({
            _id: req.params.id
        },
        function(err, restaurants) {
            if (err)
                res.send(err);

            for (prop in req.body) {
                restaurants[prop] = req.body[prop];
            }

            // save restaurants details
            restaurants.save(function(err) {
                if (err)
                    res.send(err);

                res.json({
                    message: 'Successfully Updated!'
                });
            });

        });
}
//Get the Restaurant Details for Particular Id
function getRestaurantById(req, res) {
    Restaurant.findOne({
            _id: req.params.id
        },
        function(err, restaurants) {
            if (err)
                res.send(err);
            res.json(restaurants);
        });
}
//Delete the Particular Restaurant
function deleteRestaurant(req, res) {

    Restaurant.remove({
        _id: req.params.id
    }, function(err, restaurants) {
        if (err)
            res.send(err);
        res.json({
            message: 'Successfully Deleted'
        });
    });

}

//To get the restaurant id using count of data in the collection and Model Key
function setRestaurantId(modelKey, count) {
    var suffix = "000";
    count = count + 1;
    suffix = suffix.substring(0, suffix.length - count.toString().length) + count;
    return modelKey.concat(suffix);
}

module.exports = router;