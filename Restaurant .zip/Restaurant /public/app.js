

var app = angular.module('app', ['app.data']);
