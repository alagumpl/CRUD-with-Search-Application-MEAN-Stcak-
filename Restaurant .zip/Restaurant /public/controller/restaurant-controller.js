(function() {
    
    'use strict';
    
    angular
        .module('app')
        .controller('restaurantController', RestaurantController);

    RestaurantController.$inject = ['dataService'];

    /**
     * @memberof module:restaurant
     *
     * CRUD application is performed and also displays the data
     * @requires dataService
     * @ngInject
     */
    function RestaurantController(dataService) {

        var self = this,
            data = {},
            url = "/api/restaurant";

        self.getRestaurant = getRestaurant;
        self.addRestaurant = addRestaurant;
        self.editRestaurant = editRestaurant;
        self.updateRestaurant = updateRestaurant;
        self.restaurant = null;
        self.reset = reset;
        self.setValue = setValue;
        self.isActiveValue = isActiveValue;
        self.removeData = removeData;

        //Initialize the all function,its load the entire page
        function init() {
            getRestaurant();
            self.availableLimits = paginationLimit();
        }
        /**
         * Get the all restaurants details using data service passing the URL.
         * On success call getting all restaurants details in a summary list
         */
        function getRestaurant() {
            return dataService.getData(url).then(successHandler); //passing the Get URL to dataService,its sucesss returns the data
            function successHandler(responseData) {
                self.restaurants = responseData;
            }
        }

        // Handles the error while getting false function
        function errorHandler(e) {
            console.log(e.toString());
        }
        /**
         * Add the restaurants details using data service passing the URL.
         * Its first validate the restaurants details and allow to add data.
         * On success call getting all restaurants details in a summary list.
         * @param customerType
         */
        function addRestaurant(restaurant) {
            if (!restaurantValidation(restaurant))
                return false;
            dataService.saveData(url, restaurant).then(successHandler, errorHandler); //passing the  POST URL to dataService ,its sucesss returns the data
            function successHandler(responseData) {
                alert(responseData.message);
                getRestaurant();
                self.restaurant = null;
            }
        }
    
        /**
         * To set the restaurant details in edit mode
         * @param restaurant
         */
        function editRestaurant(restaurant) {
            data = angular.copy(restaurant);
        }
        //Delete the Status in list page
        function removeData(data) {
            alert("Are you sure you want to delete this ?")
                dataService.deleteData(url, data._id, data).then(successHandler);
                function successHandler(responseData) {
                    alert(responseData.message);
                    getRestaurant();
                } //passing the UPDATE URL into dataService,while its sucesss will returns the data
            
        }
        /**
         * Update the restaurant details using data service passing the URL.
         * It's first validate the restaurant details and allow to update data.
         * On success call getting all restaurant details in a summary list.
         * @param restaurant
         */
        function updateRestaurant(restaurant) {
            if (!restaurantValidation(restaurant))  
                return false;
                dataService.updateData(url, restaurant._id, restaurant).then(successHandler); //passing the Update URL to dataService ,its sucesss returns the data
                function successHandler(responseData) {
                    alert(responseData.message);
                    getRestaurant();
                }
        }
       
        /**
         * Reset the restaurant in the summary list
         * @param restaurant
         */
        function reset(restaurant) {
            restaurant.restaurantName = data.restaurantName;
            restaurant.restaurantFood = data.restaurantFood;
            restaurant.restaurantArea = data.restaurantArea;
        }
        /**
         * By getting all restaurant details in form page while adding or updating,
         * restaurant data validate the existing data and shows warning alert message. 
         * @param restaurant
         */
        function restaurantValidation(restaurant) {
            for (var i = 0; i < self.restaurants.length; i++) {
                var value = self.restaurants[i];
                if (restaurant._id === undefined) {
                    if (value.restaurantName=== restaurant.restaurantName) {
                        alert("Restaurant Name already exists");
                        return false;
                    }
                } else {
                    if (value.restaurantId !== restaurant.restaurantId && (value.restaurantName === restaurant.restaurantName)) {
                        alert("Restaurant Name already exists");
                        return false;
                    }
                }
            }
            return true;
        }
        /**
         * Pagination
         * Initially set the available Limits and return the available limits
         */
        function paginationLimit() {
            self.availableLimit = [5,10,15,20];
            return self.availableLimit;
        }

        /**
         * Set the amount for a summary list in a page
         * @param amount
         */
        function setLimit(amount) {
            self.limit = amount;
            return self.limit;
        }

        /**
         * Initially Show amount for a summary list in a page
         * @param amount
         */
        function isActiveLimit(amount) {
            return amount === self.limit;
        }
        /**
         * Set the count for a summary list in a page
         * @param count
         */
        function setValue(count) {
            setLimit(count);
        }
        /**
         * Limiting number of document to show on the grid.
         * @param count
         */
        function isActiveValue(count) {
            isActiveLimit(count);
        }

        init();
    }

}());     