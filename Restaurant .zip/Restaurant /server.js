    // set up ========================
    var db = require('./database'); // connect to mongoDB database in local
    var logger = require('./server/utilities/logger');
    var express = require('express');
    var morgan = require('morgan'); // log requests to the console (express4)
    var bodyParser = require('body-parser'); // pull information from HTML POST (express4)
    var cookieParser = require('cookie-parser');
    var http = require('http');
    var mongoose = require('mongoose'); // mongoose for mongodb
    var app = express(); // create our app with  express
    app.use(bodyParser.urlencoded(
    {
        limit: '1000mb'
    })); // parse application/x-www-form-urlencoded
    app.use(bodyParser.json(
    {
        limit: '1000mb'
    }));
    app.use(express.static(__dirname + '/public')); // index.html from public folder
    app.use(morgan('dev')); // log every request to the console
    app.use(bodyParser.json(
    {
        type: 'application/vnd.api+json'
    })); // parse application/vnd.api+json as json
    app.use(cookieParser());
    // routes ======================================================================
    var restaurant = require('./server/routes/restaurant'); // controller for login
    
    app.use('/api', restaurant);
  
    app.get('/', function(request, response)
    { // intial load the index.html
        response.sendfile("index.html");
    });
    module.exports = app;
    app.listen(9090, function(){ //Port to access
    });
    // listen (start app with node server.js) ======================================
    console.log("App listening on port 9090");