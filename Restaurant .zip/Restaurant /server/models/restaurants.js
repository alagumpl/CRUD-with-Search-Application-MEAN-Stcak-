var mongoose = require('mongoose');
var extend = require('mongoose-schema-extend');
var commonSchema = require("./commonmodel.js");
var restaurantSchema = commonSchema.extend({
    restaurantId: {
        type: String
    },
    restaurantName: {
        type: String
    },
    restaurantFood: {
        type: String
    },
    restaurantArea: {
        type: String
    }
});
module.exports = mongoose.model('restaurant', restaurantSchema);
module.exports.schema = restaurantSchema;